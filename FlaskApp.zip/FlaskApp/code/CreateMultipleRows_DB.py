#inserting multiple rows

import sqlite3

conn = sqlite3.connect ("celebrities.db")

cursor = conn.cursor()

sql = "insert into members values (?,?,?,?,?,?)"

data = (("1","Chad","Lansing",20,"lansincx@dukes.jmu.edu","Is a Junior ISAT major at James Madison University"),(2,"Tikhon","Ivanov",22,"ivanovtp@dukes.jmu.edu","Is a Senior ISAT major at James Madison University"))

cursor.executemany(sql,data)

conn.commit()

conn.close()
