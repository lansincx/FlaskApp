#import the built in sqlite

import sqlite3

#Create or connect to an existing db
conn = sqlite3.connect("celebrities.db")

cursor = conn.cursor()

#Close the connection to the db
conn.close()
