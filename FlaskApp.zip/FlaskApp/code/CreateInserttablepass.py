#inserting a row

import sqlite3

conn = sqlite3.connect ("celebrities.db")

cursor = conn.cursor()

sql = "insert into passwords values (?,?)"

data = (("chad","chad"),
        ("tikhon","tikhon"))

cursor.executemany(sql, data)

conn.commit()

conn.close()

