#inserting a row

import sqlite3

conn = sqlite3.connect ("celebrities.db")

cursor = conn.cursor()

sql = "insert into celebs values (?,?,?,?,?,?,?)"

data = (("1","Angelina","Jolie",40,"angie@hollywood.us","http://www.nphinity.com/pics/aj.jpg", "Angelina Jolie is an American actress that has acted in movies including Tomb Raider and Mr. and Mrs. Smith."),
        ("2","Brad","Pitt",51,"brad@hollywood.us","http://www.nphinity.com/pics/bp.jpg","Brad Pitt is an American actor who has been in films including Fight Club and Oceans Eleven"),
        ("3","Snow","White",21,"sw@disney.org","http://www.nphinity.com/pics/sw.jpg","Snow White is a Disney character that lives with seven dwarves."),
        ("4","Darth","Vader",29,"dv@darkside.me","http://www.nphinity.com/pics/dv.jpg","Darth Vader is a Star Wars character that was once a Jedi named Anakin Skywalker. However, he went evil and now fights for the dark side."),
        ("5","Taylor","Swift",25,"ts@1989.us","http://nphinity.com/pics/ts.jpg","Tayor Swift is an American singer with multiple platinum albums."),
        ("6","Beyonce","Knowles",34,"beyonce@jayz.me","http://www.nphinity.com/pics/bk.jpg","Beyonce Knowles is a famous American singer who is married to famous rapper Jay-A."),
        ("7","Selena","Gomez",23,"selena@hollywood.us","http://www.nphinity.com/pics/sg.jpg","Selena Gomez is an American actress and singer who started her carrier on the Disney Channel."),
        ("8","Stephen","Curry",27,"steph@golden.bb","http://www.nphinity.com/pics/sc.jpg","Steph Curry is a three time NBA champion and two time MVP for the Golden State Warriors."))

cursor.executemany(sql, data)

conn.commit()

conn.close()
